<?php
  $level = $score = $time = 0;
?>
